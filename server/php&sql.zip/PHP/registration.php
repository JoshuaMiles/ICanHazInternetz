<?php
// Only continue if $_POST is not empty
if(!empty($_POST)){

// the name of the server to connect to
$servername = "localhost:3306";
// the username of the database
$username = "root";
// the password to the database
$password = "root";

$DB_name = "user_registration";


// attempts to make a new connection to the server given the database if the username and password are correct
$mysqli = new mysqli($servername, $username, $password, $DB_name);

  // Check our connection
 if ( $mysqli->connect_error ) {
    die( 'Connect Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error );
  } 
  // How much do we have to hash the password?

  $password_hash = password_hash($_POST['password'],PASSWORD_DEFAULT);


//The way in which to insert something into the database
//Why does it need real_escape_string?

 $sql = "INSERT INTO user ( email, first_name, last_name, password_hash  ) VALUES ( '{$mysqli->real_escape_string($_POST['email'])}', '{$mysqli->real_escape_string($_POST['first_name'])}', '{$mysqli->real_escape_string($_POST['last_name'])}', '{$mysqli->real_escape_string($password_hash)}' )";

 $insert = $mysqli->query($sql);

  // Print response from MySQL
  if ( $insert ) {
    echo "Success! Row ID: {$mysqli->insert_id}";
  } else {
    die("Error: {$mysqli->errno} : {$mysqli->error}");
  }

$mysqli->close();
}
?>


<form method="post" action="">
<input name="email" type="email">
<input name="first_name" type="text">
<input name="last_name" type="text">
<input name="password" type="password">
<input type="submit" value="Submit Form">
</form>
