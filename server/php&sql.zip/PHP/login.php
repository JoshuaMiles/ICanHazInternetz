<?php
if(!empty($_POST)){

	// the name of the server to connect to
	$servername = "localhost:3306";
	// the username of the database
	$username = "root";
	// the password to the database
	$password = "root";

	$DB_name = "user_registration";


	$mysqli = new mysqli($servername, $username, $password, $DB_name);

	if ( $mysqli->connect_error ) {
    die( 'Connect Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error );
  } 



	$checkUser = mysqli_query($mysqli, "SELECT email from user_registration.user WHERE email = $_POST['email']");

	$password = mysqli_query($mysqli, "SELECT password_hash from user_registration.user WHERE password_hash = $_POST['password'] ");

	if(!$checkUser){ 
		die("Query Failed");
	}

	if(mysqli_num_rows($checkUser)==1){
		
		if(password_verify($password,$_POST['email'])){
			echo 'somehow grant access to the user';
		}
	}

	if(password_verify("test",$password
)){
		echo "it worked";	
	} else {
		echo "didnt work";
	}
	$mysqli -> close();
}
?>


<form method="post" action="">
<input name="email" type="email">
<input name="password" type="password">
<input type="submit" value="Submit Form">
</form>